# Adventure Garden - 3 Book Build

Included:
- Grandma's Magic Garden page images
- Camping with Dad page images
- The Big Fire Truck Adventures cover as World 3
- Corrected Expo React Native app code

IMPORTANT: The uploaded Big Fire Truck Adventures PDF is a one-page full cover spread, not the story interior. World 3 is therefore included with its front cover only. Add the interior manuscript PDF later to make the complete Fire Truck reader.

To run:
1. Install Node.js on a computer.
2. Open this folder in Terminal.
3. Run `npm install`.
4. Run `npx expo start`.
5. Open Expo Go on your iPhone and scan the QR code.
