import React, { useEffect, useState } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  Image,
  Modal,
  TextInput,
  Alert,
  Dimensions,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as Speech from 'expo-speech';
import AsyncStorage from '@react-native-async-storage/async-storage';

const GMG_PAGES = [
  { image: require('./assets/books/gmg/page-1.jpg'), text: `Grandma's Magic Garden
The Secret Garden Guardians
Written by Adrionna Henry` },
  { image: require('./assets/books/gmg/page-2.jpg'), text: `Copyright
Grandma's Magic Garden: The Secret Garden Guardians
Copyright © 2026 Adrionna Henry. All rights reserved.
First Edition
This story introduces nature, herbs, flowers, and fungi for educational purposes.
Children should never eat, pick, touch, or use unknown plants or mushrooms without
the guidance of a trusted, knowledgeable adult.` },
  { image: require('./assets/books/gmg/page-3.jpg'), text: `Dedication
For every little explorer with a curious heart, a growing mind,
and a love for the world around them.` },
  { image: require('./assets/books/gmg/page-4.jpg'), text: `Meet the Garden Explorers
Milo and Jay are spending the summer with Grandma.
Behind her house is a garden full of surprises - and a tiny
red-and-gold guide named Luma.
Their adventure is about to begin!` },
  { image: require('./assets/books/gmg/page-5.jpg'), text: `The Road to Grandma's
“Are we there yet?” asked Milo.
“Not yet!” said Jay.
Outside were tall trees, tiny streams, and a forest full of secrets.
Grandma lived where the woods seemed to whisper.
This summer, the boys were about to discover why.` },
  { image: require('./assets/books/gmg/page-6.jpg'), text: `The Garden Gate
Grandma hugged Milo and Jay. “Welcome, my little explorers!”
Behind her house, they found a tiny green gate.
They pushed it open.
WHOOSH!
Something magical was waiting on the other side.` },
  { image: require('./assets/books/gmg/page-7.jpg'), text: `A Tiny Friend Appears
A red-and-gold ladybug landed on Milo’s finger.
“Hello! I’m Luma,” she said. “Come see the secrets of the garden!”
The boys stared.
A talking ladybug?
This garden really was magical!` },
  { image: require('./assets/books/gmg/page-8.jpg'), text: `Dandelion Wishes
Luma flew toward a sunny patch of dandelions.
“Aren’t those weeds?” Milo asked.
“Look closer,” said Luma.
A bee buzzed from flower to flower.
“Even little flowers can help feed pollinators.”
Jay smiled. “Can I make a wish?”
“Of course! But caring for nature is magic you can really do.”` },
  { image: require('./assets/books/gmg/page-9.jpg'), text: `The Flower Path
Next came a path filled with colorful flowers.
Some smelled sweet. Some swayed softly in the breeze.
“Plants can be special,” said Luma, “but Garden Explorers never taste or touch unknown
plants without a trusted grown-up.”
Milo and Jay nodded.
They would look, learn, and stay safe.` },
  { image: require('./assets/books/gmg/page-10.jpg'), text: `The Mushroom Circle
Under an old tree, the boys found a circle of mushrooms.
“Whoa!” said Jay. “Can we eat them?”
“No!” said Luma. “In the wild, we look - we do not taste.”
She explained that fungi help break down old leaves and return nutrients to the soil.
“Mushrooms are nature’s cleanup crew!” Milo said.` },
  { image: require('./assets/books/gmg/page-11.jpg'), text: `Garden Helpers
Buzz! Flutter! Wiggle!
The garden was busy.
Bees visited flowers. Worms moved through the soil. Birds carried seeds. A spider hurried
across her web.
“Everybody has a job,” said Luma.
Milo smiled. “The whole garden is a team!”` },
  { image: require('./assets/books/gmg/page-12.jpg'), text: `Garden Trouble
One part of the garden was dry and droopy.
“I’ll fix it!” said Milo.
“Me too!” said Jay.
“Wait,” said Luma. “Good Garden Guardians work together.”` },
  { image: require('./assets/books/gmg/page-13.jpg'), text: `Working Together
The boys checked the soil and found the broken watering hose.
Then they worked side by side, carefully helping with Grandma nearby.
Little by little, the thirsty plants perked up.
Soon, the garden looked happier.` },
  { image: require('./assets/books/gmg/page-14.jpg'), text: `The Garden's Magic
As the sun began to set, Luma glowed.
“Do you know the garden’s greatest magic?”
“Fairy dust?” Milo guessed.
“Magic soil?” Jay asked.
Luma laughed. “Teamwork!”
Flowers, animals, water, soil, and people all helped one another.
“Everything is connected,” Milo whispered.` },
  { image: require('./assets/books/gmg/page-15.jpg'), text: `Garden Guardians
Luma smiled at the boys.
“You came here as explorers,” she said. “Now you know how to care for the garden.”
Milo and Jay stood proudly together.
They were Garden Guardians!` },
  { image: require('./assets/books/gmg/page-16.jpg'), text: `The Promise
Back at Grandma’s house, she wrapped the boys in a big hug.
“What did you learn?” she asked.
“A garden is more than flowers,” said Milo.
“Every creature has an important job,” said Jay.
Together they promised:
“Be curious. Be careful. Be kind to nature!”` },
  { image: require('./assets/books/gmg/page-17.jpg'), text: `` },
  { image: require('./assets/books/gmg/page-18.jpg'), text: `` },
  { image: require('./assets/books/gmg/page-19.jpg'), text: `` },
  { image: require('./assets/books/gmg/page-20.jpg'), text: `` },
  { image: require('./assets/books/gmg/page-21.jpg'), text: `` },
  { image: require('./assets/books/gmg/page-22.jpg'), text: `Draw Your Own Magic Garden
What would grow in your magic garden?` },
  { image: require('./assets/books/gmg/page-23.jpg'), text: `Garden Guardian Certificate
This certifies that
________________________________
has learned to be curious, careful, and kind to nature.
Signed: ________________________________` },
  { image: require('./assets/books/gmg/page-24.jpg'), text: `Keep Exploring!
Look closely.
Ask questions.
Help living things.
And always explore nature with a trusted grown-up.
The garden has more secrets waiting for you.` },
];

const CWD_PAGES = [
  { image: require('./assets/books/cwd/page-1.jpg'), text: `Camping with Dad
By Adrionna Henry
A wildlife adventure about family, discovery,
and respecting the great outdoors.` },
  { image: require('./assets/books/cwd/page-2.jpg'), text: `Copyright
Camping with Dad
Copyright © 2026 Adrionna Henry
All rights reserved.
First edition.
Printed through Amazon KDP.` },
  { image: require('./assets/books/cwd/page-3.jpg'), text: `This Book Belongs To
__________________________________
Adventure awaits!` },
  { image: require('./assets/books/cwd/page-4.jpg'), text: `For Little Explorers
For every child who loves adventure,
and every dad who makes the journey special.` },
  { image: require('./assets/books/cwd/page-5.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-6.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-7.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-8.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-9.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-10.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-11.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-12.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-13.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-14.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-15.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-16.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-17.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-18.jpg'), text: `` },
  { image: require('./assets/books/cwd/page-19.jpg'), text: `What Did We Discover?
Animal tracks can tell us who passed by.
Birds and leaves make the forest feel alive.
Wild animals need space - look, don't touch.
Stay on the trail and leave nature where you found it.` },
  { image: require('./assets/books/cwd/page-20.jpg'), text: `Jordan & Amir's Explorer Rules
1. Stay close to a grown-up.
2. Respect wildlife.
3. Keep the campsite clean.
4. Listen, look, and learn.
5. Take only pictures and leave only footprints.` },
  { image: require('./assets/books/cwd/page-21.jpg'), text: `My Camping Adventure
Draw your favorite animal or outdoor discovery here!
____________________________________________
____________________________________________
____________________________________________` },
  { image: require('./assets/books/cwd/page-22.jpg'), text: `What Can You Hear?
Next time you're outside, stop and listen.
Can you hear birds? Wind? Leaves? Water?
The outdoors has its own music.` },
  { image: require('./assets/books/cwd/page-23.jpg'), text: `Keep Exploring
Be curious. Be kind. Respect nature.
Every adventure can teach us something.` },
  { image: require('./assets/books/cwd/page-24.jpg'), text: `About the Author
Adrionna Henry writes children's stories
about family, imagination, learning, and adventure.
Thank you for reading Camping with Dad!` },
];

const BFTA_PAGES = [
  { image: require('./assets/books/bfta/page-1.jpg'), text: `The Big Fire Truck Adventures
By Adrionna Henry
A story about heroes, friendship, fire safety, and big red trucks.` },
];

const worlds = [
  { id: 'gmg', title: "Grandma's Magic Garden", subtitle: 'World 1 • Read, learn & grow', emoji: '🌿🐞', pages: GMG_PAGES },
  { id: 'cwd', title: 'Camping with Dad', subtitle: 'World 2 • Family outdoor adventure', emoji: '🏕️', pages: CWD_PAGES },
  { id: 'bfta', title: 'The Big Fire Truck Adventures', subtitle: 'World 3 • Heroes, friendship & safety', emoji: '🚒', pages: BFTA_PAGES },
];

const actions = [
  ['🎮', 'Games', 'games'],
  ['🎵', 'ABC & Music', 'music'],
  ['🎨', 'Coloring', 'coloring'],
  ['⭐', 'Rewards', 'rewards'],
  ['🐾', 'Adventure Pet', 'pet'],
  ['👨‍👩‍👧', 'Parent Zone', 'parent'],
];

export default function App() {
  const [screen, setScreen] = useState('home');
  const [world, setWorld] = useState(null);
  const [page, setPage] = useState(0);
  const [stars, setStars] = useState(125);
  const [parentOpen, setParentOpen] = useState(false);
  const [answer, setAnswer] = useState('');
  const [autoRead, setAutoRead] = useState(false);
  const [badges, setBadges] = useState(['Story Star']);
  const [completed, setCompleted] = useState({ gmg: false, cwd: false, bfta: false });
  const [pet, setPet] = useState({ name: 'Sprout', type: '🐶', outfit: 'None', hunger: 80, happiness: 80, cleanliness: 80, energy: 80 });
  const [loaded, setLoaded] = useState(false);

  const goHome = () => {
    Speech.stop();
    setAutoRead(false);
    setScreen('home');
    setWorld(null);
    setPage(0);
  };

  const addStars = (n) => setStars((s) => s + n);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem('adventureGardenProgress');
        if (raw) {
          const p = JSON.parse(raw);
          if (typeof p.stars === 'number') setStars(p.stars);
          if (Array.isArray(p.badges)) setBadges(p.badges);
          if (p.completed) setCompleted(p.completed);
          if (p.pet) setPet(p.pet);
        }
      } catch (e) {
        console.warn('Could not load progress:', e);
      }
      setLoaded(true);
    })();
  }, []);

  useEffect(() => {
    if (!loaded) return;

    AsyncStorage.setItem(
      'adventureGardenProgress',
      JSON.stringify({ stars, badges, completed, pet })
    ).catch((e) => console.warn('Could not save progress:', e));
  }, [stars, badges, completed, pet, loaded]);

  const earnBadge = (name) =>
    setBadges((b) => (b.includes(name) ? b : [...b, name]));

  const speak = (text, options = {}) => {
    Speech.stop();
    Speech.speak(text || 'Welcome to Adventure Garden!', {
      rate: 0.86,
      pitch: 1.03,
      ...options,
    });
  };

  const openWorld = (w) => {
    Speech.stop();
    setAutoRead(false);
    setWorld(w);
    setPage(0);
    setScreen('reader');
  };

  const parentGate = () => setParentOpen(true);

  const checkGate = () => {
    if (answer.trim() === '7') {
      setParentOpen(false);
      setAnswer('');
      setScreen('parent');
    } else {
      Alert.alert('Try again', 'Ask a grown-up to solve the parent question.');
    }
  };

  useEffect(() => {
    if (screen !== 'reader' || !world || !autoRead) return;

    const current = world.pages[page];
    const text = current?.text?.trim();

    if (!text) {
      const timer = setTimeout(() => {
        if (page < world.pages.length - 1) {
          setPage((p) => p + 1);
        } else {
          setAutoRead(false);
        }
      }, 700);
      return () => clearTimeout(timer);
    }

    Speech.stop();
    Speech.speak(text, {
      rate: 0.86,
      pitch: 1.03,
      onDone: () => {
        if (page < world.pages.length - 1) {
          addStars(1);
          setPage((p) => p + 1);
        } else {
          setAutoRead(false);
          setCompleted((c) => ({ ...c, [world.id]: true }));
          earnBadge(world.id === 'gmg' ? 'Garden Guardian' : world.id === 'cwd' ? 'Camping Explorer' : 'Fire Safety Hero');
          addStars(20);
        }
      },
      onStopped: () => {},
      onError: () => setAutoRead(false),
    });

    return () => {
      Speech.stop();
    };
  }, [autoRead, page, screen, world]);

  const goNextPage = () => {
    Speech.stop();
    setAutoRead(false);

    if (!world) return;

    if (page === world.pages.length - 2) {
      setCompleted((c) => ({ ...c, [world.id]: true }));
      earnBadge(world.id === 'gmg' ? 'Garden Guardian' : world.id === 'cwd' ? 'Camping Explorer' : 'Fire Safety Hero');
      addStars(20);
    }

    addStars(2);
    setPage((p) => Math.min(world.pages.length - 1, p + 1));
  };

  const goPreviousPage = () => {
    Speech.stop();
    setAutoRead(false);
    setPage((p) => Math.max(0, p - 1));
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />

      <View style={styles.topbar}>
        <Pressable onPress={goHome}>
          <Text style={styles.brand}>🌿 Adventure Garden</Text>
        </Pressable>
        <View style={styles.starPill}>
          <Text style={styles.starText}>⭐ {stars}</Text>
        </View>
      </View>

      {screen === 'home' && (
        <ScrollView contentContainerStyle={styles.page}>
          <View style={styles.hero}>
            <View style={styles.guideCircle}>
              <Text style={styles.guideEmoji}>👩🏾‍🏫</Text>
            </View>

            <View style={styles.heroCopy}>
              <Text style={styles.kicker}>READ • PLAY • LEARN • GROW</Text>
              <Text style={styles.heroTitle}>
                Hi, friend! Welcome to Adventure Garden.
              </Text>
              <Text style={styles.heroBody}>
                I’m Adrionna, your adventure guide. Pick a story world and let’s explore together!
              </Text>

              <Pressable
                style={styles.listenButton}
                onPress={() =>
                  speak(
                    "Hi friend! I'm Adrionna. Welcome to Adventure Garden. Let's explore, learn, and have fun together!"
                  )
                }
              >
                <Text style={styles.listenText}>🔊 Hear My Welcome</Text>
              </Pressable>
            </View>
          </View>

          <Text style={styles.sectionTitle}>Choose Your World</Text>

          {worlds.map((w) => (
            <Pressable
              key={w.id}
              style={styles.worldCard}
              onPress={() => openWorld(w)}
            >
              <View style={styles.worldEmoji}>
                <Text style={styles.bigEmoji}>{w.emoji}</Text>
              </View>
              <View style={styles.worldCopy}>
                <Text style={styles.worldTitle}>{w.title}</Text>
                <Text style={styles.worldSub}>{w.subtitle}</Text>
                <Text style={styles.openText}>READ & LISTEN →</Text>
              </View>
            </Pressable>
          ))}

          <Text style={styles.sectionTitle}>Play & Learn</Text>

          <View style={styles.actionGrid}>
            {actions.map((a) => (
              <Pressable
                key={a[2]}
                style={[
                  styles.action,
                  a[2] === 'parent' && { backgroundColor: '#E9F7EC' },
                ]}
                onPress={() =>
                  a[2] === 'parent' ? parentGate() : setScreen(a[2])
                }
              >
                <Text style={styles.actionEmoji}>{a[0]}</Text>
                <Text style={styles.actionText}>{a[1]}</Text>
              </Pressable>
            ))}
          </View>

          <Text style={styles.safety}>
            🛡️ Kid-friendly design • Parent gate for purchases & outside links
          </Text>
        </ScrollView>
      )}

      {screen === 'reader' && world && (
        <ScrollView contentContainerStyle={styles.page}>
          <Pressable style={styles.back} onPress={goHome}>
            <Text>← Home</Text>
          </Pressable>

          <Text style={styles.readerTitle}>{world.title}</Text>
          <Text style={styles.pageCount}>
            Page {page + 1} of {world.pages.length} • Full story reader
          </Text>

          <Image
            source={world.pages[page].image}
            style={styles.bookPage}
            resizeMode="contain"
          />

          <View style={styles.readerButtons}>
            <Pressable
              style={styles.secondaryBtn}
              onPress={() => {
                setAutoRead(false);
                speak(world.pages[page].text);
                addStars(1);
              }}
            >
              <Text style={styles.secondaryText}>🔊 Read This Page</Text>
            </Pressable>

            <Pressable
              style={styles.primaryBtn}
              onPress={() => {
                if (autoRead) {
                  Speech.stop();
                  setAutoRead(false);
                } else {
                  setAutoRead(true);
                }
              }}
            >
              <Text style={styles.primaryText}>
                {autoRead ? '⏸ Stop Story' : '▶ Auto Read'}
              </Text>
            </Pressable>
          </View>

          <View style={styles.readerButtons}>
            <Pressable
              disabled={page === 0}
              style={[styles.linkBtn, page === 0 && styles.disabledBtn]}
              onPress={goPreviousPage}
            >
              <Text>← Previous</Text>
            </Pressable>

            <Pressable
              disabled={page === world.pages.length - 1}
              style={[
                styles.linkBtn,
                page === world.pages.length - 1 && styles.disabledBtn,
              ]}
              onPress={goNextPage}
            >
              <Text>Next →</Text>
            </Pressable>
          </View>

          <View style={styles.readerButtons}>
            <Pressable
              style={styles.linkBtn}
              onPress={() => {
                Speech.stop();
                setAutoRead(false);
                addStars(5);
                setScreen('games');
              }}
            >
              <Text>Play a Game 🎮</Text>
            </Pressable>

            <Pressable
              style={styles.linkBtn}
              onPress={() => {
                Speech.stop();
                setAutoRead(false);
                setPage(0);
              }}
            >
              <Text>↺ Start Over</Text>
            </Pressable>
          </View>
        </ScrollView>
      )}

      {screen === 'games' && (
        <Games onHome={goHome} addStars={addStars} speak={speak} />
      )}

      {screen === 'music' && (
        <Music onHome={goHome} addStars={addStars} speak={speak} />
      )}

      {screen === 'coloring' && (
        <Coloring onHome={goHome} addStars={addStars} />
      )}

      {screen === 'pet' && (
        <AdventurePet
          onHome={goHome}
          pet={pet}
          setPet={setPet}
          stars={stars}
          setStars={setStars}
          speak={speak}
        />
      )}

      {screen === 'rewards' && (
        <Rewards
          onHome={goHome}
          stars={stars}
          badges={badges}
          completed={completed}
        />
      )}

      {screen === 'parent' && (
        <ParentZone
          onHome={goHome}
          completed={completed}
          stars={stars}
        />
      )}

      <Modal visible={parentOpen} transparent animationType="fade">
        <View style={styles.modalShade}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Grown-ups only 🔒</Text>
            <Text style={styles.modalText}>What is 3 + 4?</Text>

            <TextInput
              value={answer}
              onChangeText={setAnswer}
              keyboardType="number-pad"
              style={styles.input}
              placeholder="Answer"
            />

            <Pressable style={styles.primaryBtn} onPress={checkGate}>
              <Text style={styles.primaryText}>Enter Parent Zone</Text>
            </Pressable>

            <Pressable
              style={styles.cancel}
              onPress={() => {
                setParentOpen(false);
                setAnswer('');
              }}
            >
              <Text>Cancel</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function Header({ title, onHome }) {
  return (
    <>
      <Pressable style={styles.back} onPress={onHome}>
        <Text>← Home</Text>
      </Pressable>
      <Text style={styles.readerTitle}>{title}</Text>
    </>
  );
}

function Games({ onHome, addStars, speak }) {
  const [msg, setMsg] = useState(
    'Tap the item that belongs in a camping backpack.'
  );

  const choose = (good) => {
    if (good) {
      setMsg('⭐ Great job! A flashlight is perfect for camping.');
      addStars(5);
      speak('Great job!');
    } else {
      setMsg('Nice try! Pick something useful outdoors.');
      speak('Nice try. Try again.');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.page}>
      <Header title="🎮 Games" onHome={onHome} />

      <View style={styles.gameCard}>
        <Text style={styles.gameQuestion}>Pack the Backpack 🎒</Text>
        <Text style={styles.gameMsg}>{msg}</Text>
        <View style={styles.choiceRow}>
          <Pressable style={styles.choice} onPress={() => choose(true)}>
            <Text style={styles.choiceEmoji}>🔦</Text>
            <Text>Flashlight</Text>
          </Pressable>
          <Pressable style={styles.choice} onPress={() => choose(false)}>
            <Text style={styles.choiceEmoji}>📺</Text>
            <Text>Television</Text>
          </Pressable>
        </View>
      </View>

      <View style={styles.gameCard}>
        <Text style={styles.gameQuestion}>Animal Tracks 🐾</Text>
        <Text style={styles.gameMsg}>
          Which animal might leave little tracks along a forest trail?
        </Text>

        <View style={styles.choiceRow}>
          <Pressable
            style={styles.choice}
            onPress={() => {
              addStars(5);
              speak('Yes! A rabbit can leave little tracks on the trail.');
            }}
          >
            <Text style={styles.choiceEmoji}>🐇</Text>
            <Text>Rabbit</Text>
          </Pressable>

          <Pressable
            style={styles.choice}
            onPress={() => speak('A fish lives in water. Try again!')}
          >
            <Text style={styles.choiceEmoji}>🐟</Text>
            <Text>Fish</Text>
          </Pressable>
        </View>
      </View>

      <View style={styles.gameCard}>
        <Text style={styles.gameQuestion}>Campfire Safety 🔥</Text>
        <Text style={styles.gameMsg}>
          What should a child do near a campfire?
        </Text>

        <View style={styles.choiceRow}>
          <Pressable
            style={styles.choice}
            onPress={() => {
              addStars(5);
              speak(
                'Great choice! Stay with a grown-up and keep a safe distance.'
              );
            }}
          >
            <Text style={styles.choiceEmoji}>👨‍👦</Text>
            <Text>Stay with a grown-up</Text>
          </Pressable>

          <Pressable
            style={styles.choice}
            onPress={() =>
              speak('No running near a campfire. Try the safe choice.')
            }
          >
            <Text style={styles.choiceEmoji}>🏃</Text>
            <Text>Run close to it</Text>
          </Pressable>
        </View>
      </View>

      <View style={styles.gameCard}>
        <Text style={styles.gameQuestion}>Find Luma 🐞</Text>
        <Text style={styles.gameMsg}>
          Which garden friend is the ladybug?
        </Text>

        <View style={styles.choiceRow}>
          <Pressable
            style={styles.choice}
            onPress={() => {
              addStars(5);
              speak('You found Luma!');
            }}
          >
            <Text style={styles.choiceEmoji}>🐞</Text>
          </Pressable>

          <Pressable
            style={styles.choice}
            onPress={() => speak('Try again')}
          >
            <Text style={styles.choiceEmoji}>🦋</Text>
          </Pressable>

          <Pressable
            style={styles.choice}
            onPress={() => speak('Try again')}
          >
            <Text style={styles.choiceEmoji}>🐝</Text>
          </Pressable>
        </View>
      </View>
    </ScrollView>
  );
}

function Music({ onHome, addStars, speak }) {
  const letters = [
    ['A', 'Adventure'],
    ['B', 'Backpack'],
    ['G', 'Garden'],
    ['L', 'Ladybug'],
    ['S', 'Stars'],
  ];

  return (
    <ScrollView contentContainerStyle={styles.page}>
      <Header title="🎵 ABC & Music" onHome={onHome} />
      <Text style={styles.gameMsg}>Tap a letter to hear it.</Text>

      <View style={styles.actionGrid}>
        {letters.map(([l, w]) => (
          <Pressable
            key={l}
            style={styles.letter}
            onPress={() => {
              speak(`${l} is for ${w}`);
              addStars(1);
            }}
          >
            <Text style={styles.letterBig}>{l}</Text>
            <Text>{w}</Text>
          </Pressable>
        ))}
      </View>

      <Pressable
        style={styles.primaryBtn}
        onPress={() => {
          speak(
            'A B C. Adventure, backpack, garden, ladybug, stars. Keep learning and keep growing!'
          );
          addStars(5);
        }}
      >
        <Text style={styles.primaryText}>▶ ABC Adventure Chant</Text>
      </Pressable>
    </ScrollView>
  );
}

function Coloring({ onHome, addStars }) {
  const [pick, setPick] = useState('✨');

  return (
    <ScrollView contentContainerStyle={styles.page}>
      <Header title="🎨 Coloring" onHome={onHome} />

      <View style={styles.gameCard}>
        <Text style={styles.coloringArt}>🌷🐞🌻{pick}</Text>
        <Text style={styles.gameMsg}>Choose a magical sparkle color.</Text>

        <View style={styles.choiceRow}>
          {['🔴', '🟡', '🟣', '🔵'].map((c) => (
            <Pressable
              key={c}
              style={styles.choice}
              onPress={() => {
                setPick(c);
                addStars(1);
              }}
            >
              <Text style={styles.choiceEmoji}>{c}</Text>
            </Pressable>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}


function AdventurePet({ onHome, pet, setPet, stars, setStars, speak }) {
  const [nameDraft, setNameDraft] = useState(pet.name || 'Sprout');
  const petChoices = ['🐶', '🐱', '🐰'];
  const outfits = [
    { name: 'None', icon: '✨', cost: 0 },
    { name: 'Garden Cape', icon: '🌿', cost: 20 },
    { name: 'Camp Hat', icon: '🏕️', cost: 25 },
    { name: 'Firefighter Helmet', icon: '🚒', cost: 30 },
    { name: 'Star Glasses', icon: '⭐', cost: 15 },
  ];

  const clamp = (n) => Math.max(0, Math.min(100, n));
  const updateNeed = (key, amount) =>
    setPet((current) => ({ ...current, [key]: clamp((current[key] || 0) + amount) }));

  const care = (type) => {
    if (type === 'feed') {
      updateNeed('hunger', 20);
      updateNeed('happiness', 4);
      speak(`${pet.name} says yum yum!`);
    }
    if (type === 'bath') {
      updateNeed('cleanliness', 25);
      speak(`${pet.name} is squeaky clean!`);
    }
    if (type === 'play') {
      updateNeed('happiness', 20);
      updateNeed('energy', -8);
      speak(`${pet.name} loves playing with you!`);
    }
    if (type === 'sleep') {
      updateNeed('energy', 30);
      speak(`${pet.name} had a cozy nap.`);
    }
  };

  const buyOutfit = (item) => {
    if (item.cost > stars) {
      Alert.alert('Not enough stars', 'Read stories and play games to earn more stars.');
      return;
    }
    if (item.name !== pet.outfit && item.cost > 0) setStars((s) => s - item.cost);
    setPet((current) => ({ ...current, outfit: item.name }));
    speak(`${pet.name} is wearing ${item.name}.`);
  };

  const saveName = () => {
    const clean = nameDraft.trim().slice(0, 16);
    if (!clean) return;
    setPet((current) => ({ ...current, name: clean }));
    speak(`Hi ${clean}!`);
  };

  const meter = (label, value, emoji) => (
    <View style={styles.petMeterWrap}>
      <View style={styles.petMeterLabelRow}>
        <Text style={styles.petMeterLabel}>{emoji} {label}</Text>
        <Text style={styles.petMeterValue}>{value}%</Text>
      </View>
      <View style={styles.petMeterTrack}>
        <View style={[styles.petMeterFill, { width: `${value}%` }]} />
      </View>
    </View>
  );

  return (
    <ScrollView contentContainerStyle={styles.page}>
      <Header title="🐾 Adventure Pet" onHome={onHome} />
      <Text style={styles.gameMsg}>Take care of your little garden buddy and use stars to unlock outfits.</Text>

      <View style={styles.petHomeCard}>
        <Text style={styles.petOutfitIcon}>{outfits.find((o) => o.name === pet.outfit)?.icon || '✨'}</Text>
        <Text style={styles.petEmoji}>{pet.type}</Text>
        <Text style={styles.petName}>{pet.name}</Text>
        <Text style={styles.petOutfitText}>{pet.outfit}</Text>
      </View>

      <Text style={styles.sectionTitle}>Choose Your Pet</Text>
      <View style={styles.choiceRow}>
        {petChoices.map((choice) => (
          <Pressable
            key={choice}
            style={[styles.choice, pet.type === choice && styles.petSelected]}
            onPress={() => setPet((current) => ({ ...current, type: choice }))}
          >
            <Text style={styles.choiceEmoji}>{choice}</Text>
          </Pressable>
        ))}
      </View>

      <Text style={styles.sectionTitle}>Name Your Pet</Text>
      <View style={styles.petNameRow}>
        <TextInput
          value={nameDraft}
          onChangeText={setNameDraft}
          style={[styles.input, styles.petNameInput]}
          placeholder="Pet name"
          maxLength={16}
        />
        <Pressable style={styles.petSaveBtn} onPress={saveName}>
          <Text style={styles.primaryText}>Save</Text>
        </Pressable>
      </View>

      <Text style={styles.sectionTitle}>Care</Text>
      {meter('Hunger', pet.hunger, '🍎')}
      {meter('Happiness', pet.happiness, '❤️')}
      {meter('Cleanliness', pet.cleanliness, '🛁')}
      {meter('Energy', pet.energy, '😴')}

      <View style={styles.actionGrid}>
        <Pressable style={styles.action} onPress={() => care('feed')}><Text style={styles.actionEmoji}>🍎</Text><Text style={styles.actionText}>Feed</Text></Pressable>
        <Pressable style={styles.action} onPress={() => care('bath')}><Text style={styles.actionEmoji}>🛁</Text><Text style={styles.actionText}>Bathe</Text></Pressable>
        <Pressable style={styles.action} onPress={() => care('play')}><Text style={styles.actionEmoji}>🎾</Text><Text style={styles.actionText}>Play</Text></Pressable>
        <Pressable style={styles.action} onPress={() => care('sleep')}><Text style={styles.actionEmoji}>🌙</Text><Text style={styles.actionText}>Sleep</Text></Pressable>
      </View>

      <Text style={styles.sectionTitle}>Dress Up</Text>
      <Text style={styles.gameMsg}>You have ⭐ {stars} stars.</Text>
      {outfits.map((item) => (
        <Pressable key={item.name} style={[styles.petShopItem, pet.outfit === item.name && styles.petSelected]} onPress={() => buyOutfit(item)}>
          <Text style={styles.petShopIcon}>{item.icon}</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.worldTitle}>{item.name}</Text>
            <Text style={styles.worldSub}>{item.cost === 0 ? 'Free' : `${item.cost} stars`}</Text>
          </View>
          <Text style={styles.openText}>{pet.outfit === item.name ? 'WEARING ✓' : 'CHOOSE →'}</Text>
        </Pressable>
      ))}

      <Text style={styles.safety}>More pet rooms, toys, food, and decorations can be added later.</Text>
    </ScrollView>
  );
}

function Rewards({ onHome, stars, badges, completed }) {
  return (
    <ScrollView contentContainerStyle={styles.page}>
      <Header title="⭐ Rewards" onHome={onHome} />

      <Text style={styles.rewardTotal}>{stars} Stars</Text>

      <View style={styles.badges}>
        {badges.map((badge) => (
          <Text key={badge} style={styles.badge}>
            ⭐{'\n'}
            {badge}
          </Text>
        ))}

        {!completed.gmg && (
          <Text style={[styles.badge, styles.lockedBadge]}>
            🔒{'\n'}Garden Guardian
          </Text>
        )}

        {!completed.cwd && (
          <Text style={[styles.badge, styles.lockedBadge]}>
            🔒{'\n'}Camping Explorer
          </Text>
        )}
      </View>

      <Text style={styles.safety}>
        Future release: stickers, surprise animations, and unlockable worlds.
      </Text>
    </ScrollView>
  );
}

function ParentZone({ onHome, completed, stars }) {
  return (
    <ScrollView contentContainerStyle={styles.page}>
      <Header title="👨‍👩‍👧 Parent Zone" onHome={onHome} />

      <View style={styles.parentCard}>
        <Text style={styles.parentTitle}>Reading Progress</Text>
        <Text>
          Grandma's Magic Garden • {completed.gmg ? 'Completed' : 'In progress'}
        </Text>
        <Text>
          Camping with Dad • {completed.cwd ? 'Completed' : 'In progress'}
        </Text>
        <Text>
          The Big Fire Truck Adventures • {completed.bfta ? 'Completed' : 'In progress'}
        </Text>
        <Text>Stars earned • {stars}</Text>
      </View>

      <View style={styles.parentCard}>
        <Text style={styles.parentTitle}>Adventure Garden Store</Text>
        <Text>
          Future book worlds and activity packs will appear here. Store
          transactions will use Apple In-App Purchase and Google Play Billing
          after the developer accounts are connected.
        </Text>

        <Pressable
          style={[styles.primaryBtn, { marginTop: 12 }]}
          onPress={() =>
            Alert.alert(
              'Store setup',
              'The parent-only store screen is ready. Real purchases will be connected during store integration.'
            )
          }
        >
          <Text style={styles.primaryText}>Preview Store</Text>
        </Pressable>
      </View>

      <View style={styles.parentCard}>
        <Text style={styles.parentTitle}>Privacy & Controls</Text>
        <Text>
          No open chat. No child-to-child messaging. External links and
          purchases should remain parent-gated.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#FFFDF5' },
  topbar: {
    paddingHorizontal: 18,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#E9E3D6',
    backgroundColor: '#FFFDF5',
  },
  brand: { fontSize: 20, fontWeight: '900', color: '#376B3D' },
  starPill: {
    backgroundColor: '#FFE27A',
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 20,
  },
  starText: { fontWeight: '900' },
  page: { padding: 18, paddingBottom: 48 },
  hero: {
    backgroundColor: '#EAF7DD',
    borderRadius: 28,
    padding: 18,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  guideCircle: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: '#FFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  guideEmoji: { fontSize: 56 },
  heroCopy: { flex: 1 },
  kicker: {
    fontSize: 11,
    fontWeight: '900',
    color: '#8B4A91',
    letterSpacing: 1.2,
  },
  heroTitle: {
    fontSize: 22,
    fontWeight: '900',
    color: '#3B5836',
    marginTop: 5,
  },
  heroBody: {
    fontSize: 14,
    color: '#5B6559',
    marginTop: 6,
    lineHeight: 20,
  },
  listenButton: {
    marginTop: 10,
    alignSelf: 'flex-start',
    backgroundColor: '#754AA8',
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 14,
  },
  listenText: { color: '#fff', fontWeight: '800' },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '900',
    marginTop: 26,
    marginBottom: 12,
    color: '#3C5638',
  },
  worldCard: {
    backgroundColor: '#FFF',
    borderRadius: 24,
    padding: 14,
    flexDirection: 'row',
    gap: 14,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#E4EEDC',
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
  },
  worldEmoji: {
    width: 78,
    height: 78,
    borderRadius: 20,
    backgroundColor: '#F0F7DE',
    alignItems: 'center',
    justifyContent: 'center',
  },
  bigEmoji: { fontSize: 38 },
  worldCopy: { flex: 1, justifyContent: 'center' },
  worldTitle: { fontSize: 20, fontWeight: '900' },
  worldSub: { color: '#6C766A', marginTop: 3 },
  openText: { color: '#557E47', fontWeight: '900', marginTop: 8 },
  actionGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  action: {
    width: '48%',
    minHeight: 105,
    borderRadius: 22,
    backgroundColor: '#F5EEFB',
    padding: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionEmoji: { fontSize: 32 },
  actionText: { fontWeight: '900', marginTop: 7, textAlign: 'center' },
  safety: {
    marginTop: 20,
    color: '#687468',
    textAlign: 'center',
    lineHeight: 20,
  },
  back: {
    alignSelf: 'flex-start',
    backgroundColor: '#F0EDDF',
    paddingHorizontal: 13,
    paddingVertical: 8,
    borderRadius: 16,
  },
  readerTitle: {
    fontSize: 28,
    fontWeight: '900',
    color: '#3C5638',
    marginTop: 18,
  },
  pageCount: { color: '#718071', marginTop: 5, marginBottom: 12 },
  bookPage: {
    width: '100%',
    height: Dimensions.get('window').height * 0.55,
    backgroundColor: '#F7F3E7',
    borderRadius: 18,
  },
  readerButtons: { flexDirection: 'row', gap: 10, marginTop: 14 },
  primaryBtn: {
    flex: 1,
    backgroundColor: '#5C8C4C',
    padding: 14,
    borderRadius: 16,
    alignItems: 'center',
  },
  primaryText: { color: '#fff', fontWeight: '900' },
  secondaryBtn: {
    flex: 1,
    backgroundColor: '#7F53C7',
    padding: 14,
    borderRadius: 16,
    alignItems: 'center',
  },
  secondaryText: { color: '#fff', fontWeight: '900' },
  linkBtn: {
    flex: 1,
    backgroundColor: '#F3F0E5',
    padding: 12,
    borderRadius: 14,
    alignItems: 'center',
  },
  disabledBtn: { opacity: 0.45 },
  gameCard: {
    backgroundColor: '#FFF',
    padding: 18,
    borderRadius: 24,
    marginTop: 16,
    borderWidth: 1,
    borderColor: '#EAE4D8',
  },
  gameQuestion: { fontSize: 22, fontWeight: '900', textAlign: 'center' },
  gameMsg: {
    textAlign: 'center',
    fontSize: 16,
    color: '#667063',
    marginVertical: 12,
  },
  choiceRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    justifyContent: 'center',
  },
  choice: {
    backgroundColor: '#F8F4EA',
    borderRadius: 18,
    padding: 16,
    minWidth: 90,
    alignItems: 'center',
  },
  choiceEmoji: { fontSize: 38 },
  letter: {
    width: '30%',
    minHeight: 110,
    borderRadius: 20,
    backgroundColor: '#F5EEFB',
    alignItems: 'center',
    justifyContent: 'center',
  },
  letterBig: { fontSize: 42, fontWeight: '900', color: '#754AA8' },
  coloringArt: { fontSize: 65, textAlign: 'center', marginVertical: 28 },
  rewardTotal: {
    fontSize: 44,
    fontWeight: '900',
    color: '#D2A51C',
    textAlign: 'center',
    marginVertical: 22,
  },
  badges: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'center',
  },
  badge: {
    width: '44%',
    backgroundColor: '#FFF5C7',
    padding: 22,
    borderRadius: 22,
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '800',
    lineHeight: 30,
  },
  lockedBadge: {
    opacity: 0.45,
  },
  parentCard: {
    backgroundColor: '#EAF6EC',
    padding: 18,
    borderRadius: 20,
    marginTop: 14,
  },
  parentTitle: { fontSize: 20, fontWeight: '900', marginBottom: 8 },
  modalShade: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,.45)',
    justifyContent: 'center',
    padding: 25,
  },
  modalCard: {
    backgroundColor: '#FFF',
    borderRadius: 26,
    padding: 22,
  },
  modalTitle: { fontSize: 24, fontWeight: '900' },
  modalText: { fontSize: 17, marginTop: 10 },
  input: {
    borderWidth: 1,
    borderColor: '#D7D1C7',
    borderRadius: 14,
    padding: 12,
    fontSize: 18,
    marginVertical: 14,
  },
  cancel: { padding: 14, alignItems: 'center' },
  petHomeCard: { backgroundColor: '#EAF7DD', borderRadius: 28, padding: 24, alignItems: 'center', marginTop: 16, borderWidth: 1, borderColor: '#DDEBCF' },
  petEmoji: { fontSize: 92 },
  petOutfitIcon: { fontSize: 42, marginBottom: -8 },
  petName: { fontSize: 28, fontWeight: '900', color: '#3C5638', marginTop: 5 },
  petOutfitText: { color: '#754AA8', fontWeight: '800', marginTop: 4 },
  petSelected: { borderWidth: 2, borderColor: '#5C8C4C' },
  petNameRow: { flexDirection: 'row', gap: 10, alignItems: 'center' },
  petNameInput: { flex: 1, marginVertical: 0 },
  petSaveBtn: { backgroundColor: '#5C8C4C', paddingHorizontal: 18, paddingVertical: 14, borderRadius: 14 },
  petMeterWrap: { marginBottom: 12 },
  petMeterLabelRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  petMeterLabel: { fontWeight: '800', color: '#3C5638' },
  petMeterValue: { color: '#687468', fontWeight: '700' },
  petMeterTrack: { height: 12, backgroundColor: '#E8E4D8', borderRadius: 8, overflow: 'hidden' },
  petMeterFill: { height: '100%', backgroundColor: '#76A95E', borderRadius: 8 },
  petShopItem: { backgroundColor: '#FFF', borderRadius: 18, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10, borderWidth: 1, borderColor: '#EAE4D8' },
  petShopIcon: { fontSize: 34 },
});
